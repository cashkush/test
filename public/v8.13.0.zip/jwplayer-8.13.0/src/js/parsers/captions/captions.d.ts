export type CaptionEntryData = {
    begin?: number;
    text?: string;
    end?: number;
};
