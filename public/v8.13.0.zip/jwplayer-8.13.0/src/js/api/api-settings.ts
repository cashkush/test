declare global {
    const __DEBUG__: boolean;
}

export default {
    debug: __DEBUG__
};
