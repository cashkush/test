/* eslint-disable no-unused-vars */

var global2ScriptLoaded = true;
