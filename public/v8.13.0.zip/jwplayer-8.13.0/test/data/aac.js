export default {
    tagged: {
        file: 'sample',
        type: 'aac'
    }
};
