export default {
    file: '//playertest.longtailvideo.com/barsandtone.mp4',
    controls: false,
};
